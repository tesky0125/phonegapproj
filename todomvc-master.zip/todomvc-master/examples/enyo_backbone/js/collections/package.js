/*global enyo:false */
enyo.depends(
	'TaskCollection.js'
);
